
<!-- PAGE : RESUME -->
        <section id="resume" class="page wrapper resume" data-x="1500" data-y="250" data-rotate="-90" data-scale="16">
        	
            <!-- PAGE TITLE -->
            <h2 class="caption"><span>rEsUm3</span></h2>
            
            <div class="iscroll-wrapper">
                <div class="scroller container">
                    
                    
                    <!--row-->
                    <div class="row">
                      
                      	
                        <!--column 6/12-->
                    	<div class="span6">
                        	
                            
                            <!-- EMPLOYMENT -->
                            <div class="history-group">
                            
                                <h3><span class="label black">Employment</span></h3>
                                
                                <div class="history-unit">
                                    <h4>Freelance Designer<span class="work-time">2009 - Present</span></h4>
                                    <h5>Self Employed</h5>
                                    <p>Worked in so many projects regarding web for best clients around the world also few experiences based on my job.</p>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>WP Developer <span class="work-time">Hobby</span></h4>
                                    <h5>Self Employed</h5>
                                    <p>Also i have designed levels of some cool WP Based themes.</p>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>Web Developer / SEO Specialist<span class="work-time">2015-2016</span></h4>
                                    <h5>VIP Web</h5>
                                    <p>Worked in so many projects for best clients around the world.</p>
                                </div>
                            
                            </div>
                            <!-- EMPLOYMENT -->
                            
                            
                            
                            
                            <!-- EDUCATION -->
                            <div class="history-group">
                            
                                <h3><span class="label black">Education</span></h3>
                                
                                <div class="history-unit">
                                    <h4>BSC in Computer Science <span class="work-time">2013 - 2017</span></h4>
                                    <h5>CCT College</h5>
                                    <p>Studying BSC in CCT college, Dublin on Computer Science.</p>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>BA <span class="work-time">2008 - 2011</span></h4>
                                    <h5>Tribhuwan University</h5>
                                    <p>I get my Bachelor Degree on management (Account and Finance) in Tribhuwan University.</p>
                                </div>
                            
                            </div>
                            <!-- EDUCATION -->
                            
                            <div class="launch cv">
                                <a href="#" class="btn">DOWNLOAD CV</a>
                            </div>
                            
                        </div>
                        <!--column 6/12-->
                        
                        
                        
                        
                        <!--column 6/12-->
                    	<div class="span5 offset1">
                        
                        	<!-- DEV SKILLS -->
                            <div class="history-group">
                            
                                <h3><span class="label black">Development Skills</span></h3>
                                
                                <div class="history-unit">
                                    <h4>HTML5</h4>
                                    <div class="bar" data-percent="90">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>CSS3</h4>
                                    <div class="bar" data-percent="60">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>Wordpress</h4>
                                    <div class="bar" data-percent="99">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                            
                            <div class="history-unit">
                                    <h4>jQuery</h4>
                                    <div class="bar" data-percent="50">
                                        <div class="progress"></div>
                                    </div>
                                </div>

                            <div class="history-unit">
                                    <h4>JAVA</h4>
                                    <div class="bar" data-percent="80">
                                        <div class="progress"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- DEV SKILLS -->
                            
                            
                            <!-- DESIGN SKILLS -->
                            <div class="history-group">
                            
                                <h3><span class="label black">Design Skills</span></h3>
                                
                                <div class="history-unit">
                                    <h4>Dreamweaver</h4>
                                    <div class="bar" data-percent="60">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>Photoshop</h4>
                                    <div class="bar" data-percent="60">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                                
                                <div class="history-unit">
                                    <h4>Illustrator</h4>
                                    <div class="bar" data-percent="40">
                                    	<div class="progress"></div>
                                    </div>
                                </div>
                            
                            </div>
                            <!-- DESIGN SKILLS -->
                            
                            
                             
                            
                        
                        </div>
                        <!--column 6/12-->
                        
                        
                        
                      
                    </div>
                    <!--row-->

                    
                </div>
                <!--end scroller-->
            </div>
            <!--iscroll-wrapper-->
            
        
        </section>
        <!-- PAGE : RESUME -->
